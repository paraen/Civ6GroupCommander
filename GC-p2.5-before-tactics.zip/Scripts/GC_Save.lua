-- Save-backed state only; this bridge never issues unit commands.
local function SaveMarch(owner,params)
  if type(owner)~="number" or not Players[owner] or type(params)~="table" then return; end
  local value=params.value;
  if type(value)~="string" or #value>12000 or value:find("[^%d,;%-]") then return; end
  if value~="" then
    local version,storedOwner=value:match("^(%d+),(%d+),");
    if version~="1" or tonumber(storedOwner)~=owner then return; end
  end
  Players[owner]:SetProperty("GC_MarchV1",value);
  print("[GC][MARCH_SAVED] owner="..owner.." empty="..tostring(value==""));
end
GameEvents.GC_SaveMarchV1.Add(SaveMarch);
print("[GC][SAVE_BRIDGE_READY] version=1");
