-- One confirmed attack at a time against a locked, visible unit identity.
-- First attack slice: attacks legal from the current position, no auto approach.
GC_Attack={};
local A=GC_Attack;
local batch=nil;
local function AtWar(owner,other)
  local player=Players[owner];
  return player and player:GetDiplomacy():IsAtWarWith(other);
end
function A.Target(plotID)
  local owner=Game.GetLocalPlayer();
  local plot=plotID and Map.GetPlotByIndex(plotID);
  local vis=PlayersVisibility[owner];
  if not plot or not vis or not vis:IsVisible(plot:GetX(),plot:GetY()) then return nil; end
  local enemies={}; local foreign=false;
  for _,unit in ipairs(Units.GetUnitsInPlotLayerID(plot:GetX(),plot:GetY(),MapLayers.ANY)) do
    if unit:GetOwner()~=owner and vis:IsUnitVisible(unit) then
      if AtWar(owner,unit:GetOwner()) then enemies[#enemies+1]=unit; else foreign=true; end
    end
  end
  if #enemies==0 then return nil; end
  if plot:IsCity() then return nil,"城市攻击尚未适配；请使用原生攻击或选择城外敌军"; end
  if foreign then return nil,"目标格还存在未交战单位；请使用原生单兵操作"; end
  table.sort(enemies,function(a,b)
    local ai,bi=GameInfo.Units[a:GetType()],GameInfo.Units[b:GetType()];
    local ac,bc=(ai.Combat or 0)>0,(bi.Combat or 0)>0;
    if ac~=bc then return ac; end
    if a:GetOwner()~=b:GetOwner() then return a:GetOwner()<b:GetOwner(); end
    return a:GetID()<b:GetID();
  end);
  local unit=enemies[1];
  return {owner=unit:GetOwner(),id=unit:GetID(),plot=plotID,x=plot:GetX(),y=plot:GetY()};
end
function A.CheckTarget(target,owner)
  local vis=PlayersVisibility[owner];
  if not vis or not vis:IsVisible(target.x,target.y) then return nil,"目标已失去视野"; end
  if not AtWar(owner,target.owner) then return nil,"外交关系已变化"; end
  local player=Players[target.owner];
  local unit=player and player:GetUnits():FindID(target.id);
  if not unit or unit:IsDelayedDeath() then return nil,"目标已消灭或消失"; end
  if unit:GetX()~=target.x or unit:GetY()~=target.y then return nil,"目标已移动"; end
  if not vis:IsUnitVisible(unit) then return nil,"目标已不可见"; end
  local current,blocked=A.Target(target.plot);
  if blocked or not current or current.owner~=target.owner or current.id~=target.id then
    return nil,"目标格的守军已变化";
  end
  return unit;
end
function A.Operation(unit,target)
  if not unit or unit:IsDelayedDeath() then return nil,"单位已不存在"; end
  local info=GameInfo.Units[unit:GetType()];
  if not info or ((info.Combat or 0)<=0 and (info.RangedCombat or 0)<=0 and (info.Bombard or 0)<=0) then
    return nil,"非战斗单位待命";
  end
  if unit:GetFormationUnitCount()>1 then return nil,"护送队待适配，保持链接"; end
  if unit:GetMovesRemaining()<=0 or unit:GetAttacksRemaining()<=0 then return nil,"本回合不能继续攻击"; end
  local args={[UnitOperationTypes.PARAM_X]=target.x,[UnitOperationTypes.PARAM_Y]=target.y,
    [UnitOperationTypes.PARAM_MODIFIERS]=UnitOperationMoveModifiers.NONE};
  local op=UnitOperationTypes.RANGE_ATTACK;
  if info.Domain=="DOMAIN_AIR" then
    op=UnitOperationTypes.AIR_ATTACK; args[UnitOperationTypes.PARAM_MODIFIERS]=UnitOperationMoveModifiers.ATTACK;
  elseif (info.RangedCombat or 0)<=0 and (info.Bombard or 0)<=0 then
    if Map.GetPlotDistance(unit:GetX(),unit:GetY(),target.x,target.y)~=1 then
      return nil,"近战须先移动到目标相邻格";
    end
    op=UnitOperationTypes.MOVE_TO; args[UnitOperationTypes.PARAM_MODIFIERS]=UnitOperationMoveModifiers.ATTACK;
  end
  local warChanges=CombatManager.IsAttackChangeWarState(unit:GetComponentID(),target.x,target.y);
  if warChanges and #warChanges>0 then return nil,"此攻击将引发新的战争"; end
  if not UnitManager.CanStartOperation(unit,op,nil,args) then return nil,"当前位置无法攻击（射程、视线或单位状态）"; end
  return op,args;
end
function A.Plan(selected,target)
  local owner=Game.GetLocalPlayer();
  local plan={kind="attack",owner=owner,turn=Game.GetCurrentGameTurn(),target=target,orders={},waiting={}};
  if not Players[owner] or not Players[owner]:IsTurnActive() then plan.error="请在自己的回合下令"; return plan; end
  local valid,reason=A.CheckTarget(target,owner);
  if not valid then plan.error=reason; return plan; end
  local ids={}; for id in pairs(selected) do ids[#ids+1]=id; end; table.sort(ids);
  if #ids==0 then plan.error="请先框选单位"; return plan; end
  if #ids>64 then plan.error="每批最多 64 个单位"; return plan; end
  for _,id in ipairs(ids) do
    local unit=Players[owner]:GetUnits():FindID(id);
    local op,args=A.Operation(unit,target);
    if op then
      plan.orders[#plan.orders+1]={id=id,priority=op==UnitOperationTypes.MOVE_TO and 2 or 1};
    else
      plan.waiting[#plan.waiting+1]={id=id,reason=args};
      print("[GC][ATTACK_WAIT] unit="..id.." reason="..args);
    end
  end
  table.sort(plan.orders,function(a,b) if a.priority~=b.priority then return a.priority<b.priority; end; return a.id<b.id; end);
  print("[GC][ATTACK_PLAN] target="..target.owner..":"..target.id.." orders="..#plan.orders.." waiting="..#plan.waiting);
  return plan;
end
function A.Cancel(reason)
  local old=batch; batch=nil;
  if not old then return; end
  if old.pending and old.pending.op==UnitOperationTypes.MOVE_TO then
    local player=Players[old.plan.owner];
    local unit=player and player:GetUnits():FindID(old.pending.id);
    if unit and Game.GetLocalPlayer()==old.plan.owner then
      local ok,err=pcall(function()
        if UnitManager.CanStartCommand(unit,UnitCommandTypes.CANCEL) then UnitManager.RequestCommand(unit,UnitCommandTypes.CANCEL); end
      end);
      if not ok then print("[GC][ATTACK_CLEAR_ERROR] "..tostring(err)); end
    end
  end
  print("[GC][ATTACK_CANCEL] reason="..tostring(reason).." requested="..old.requested.." confirmed="..old.confirmed);
end
function A.Start(plan,report)
  A.Cancel("new_batch");
  if not plan or plan.error or #plan.orders==0 or plan.owner~=Game.GetLocalPlayer()
      or plan.turn~=Game.GetCurrentGameTurn() or not Players[plan.owner]:IsTurnActive() then return false; end
  if not A.CheckTarget(plan.target,plan.owner) then return false; end
  batch={plan=plan,report=report,index=1,requested=0,confirmed=0,skipped=0,elapsed=0};
  report("开始群体攻击；Esc 停止后续下令");
  return true;
end
function A.Update(delta)
  local b=batch; if not b then return; end
  b.elapsed=b.elapsed+delta; if b.elapsed<0.1 then return; end; b.elapsed=0;
  if Game.GetLocalPlayer()~=b.plan.owner or Game.GetCurrentGameTurn()~=b.plan.turn or not Players[b.plan.owner]:IsTurnActive() then
    b.report("回合或玩家变化；攻击停止"); A.Cancel("turn_changed"); return;
  end
  if UI.IsGameCoreBusy() then
    if b.pending and UI.GetElapsedTime()-b.pending.since>20 then b.report("攻击结果超时；停止后续命令"); A.Cancel("timeout"); end
    return;
  end
  local target,reason=A.CheckTarget(b.plan.target,b.plan.owner);
  if not target then b.report(reason.."；停止后续攻击"); A.Cancel("target_changed: "..reason); return; end
  local units=Players[b.plan.owner]:GetUnits();
  if b.pending then
    local u=units:FindID(b.pending.id);
    if not u or u:IsDelayedDeath() or u:GetAttacksRemaining()<b.pending.attacks then
      b.confirmed=b.confirmed+1;
      print("[GC][ATTACK_CONFIRMED] unit="..b.pending.id);
      b.pending=nil;
    elseif UI.GetElapsedTime()-b.pending.since>20 then
      b.report("攻击结果未确认；停止后续命令"); A.Cancel("timeout"); return;
    else return; end
  end
  local order=b.plan.orders[b.index];
  if not order then
    b.report("攻击结束：已确认 "..b.confirmed.."；跳过 "..b.skipped.."；待命 "..#b.plan.waiting);
    print("[GC][ATTACK_COMPLETE] requested="..b.requested.." confirmed="..b.confirmed.." skipped="..b.skipped);
    batch=nil; return;
  end
  b.index=b.index+1;
  local unit=units:FindID(order.id); local op,args=A.Operation(unit,b.plan.target);
  if not op then b.skipped=b.skipped+1; print("[GC][ATTACK_SKIP] unit="..order.id.." reason="..args); return; end
  b.pending={id=order.id,op=op,attacks=unit:GetAttacksRemaining(),since=UI.GetElapsedTime()};
  b.requested=b.requested+1;
  UnitManager.RequestOperation(unit,op,args);
  print("[GC][ATTACK_REQUEST] unit="..order.id.." target="..b.plan.target.owner..":"..b.plan.target.id.." operation="..tostring(op));
  b.report("攻击中：已请求 "..b.requested.."；已确认 "..b.confirmed);
end
